const geradorSenha = function(quantidade, numeros = false, maiusculas = false, minusculas = false, simbolo = false){
    
    function letraMinuscula() {
        const alphabet = 'abcdefghijklmnopqrstuvwxyz';
        const randomIndex = Math.floor(Math.random() * alphabet.length);
        return alphabet[randomIndex];
    }
    
    function letraMaiuscula(){
        const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const randomIndex = Math.floor(Math.random() * alphabet.length);
        return alphabet[randomIndex];
    }
    
    function geradorNumeros(){
        const numeroAleatorio = Math.floor(Math.random() * 10);
        return String(numeroAleatorio);
    }
    
    
    function simbolos(){
        const simbolo = '!@#$%¨&*()^~/?';
        const randomIndex = Math.floor(Math.random() * simbolo.length);
        return simbolo[randomIndex];
    }



    let senha = ""
    for (i = 0; i < quantidade; i++){
        if(maiusculas === true && senha.length < quantidade){
            senha += letraMaiuscula()
        }

        if(minusculas === true && senha.length < quantidade){
            senha += letraMinuscula()
        }

        if(numeros === true && senha.length < quantidade){
            senha += geradorNumeros()
        }

        if(simbolo === true && senha.length < quantidade){
            senha += simbolos()
        }
    }

    return senha
}


// const verificadorCaracteres = () =>{
//     const quantCaracteres = document.querySelector("#quantidade-caracteres")
//     const adcNumeros = document.querySelector("#numeros")
//     const adcMaiusculas = document.querySelector("#maiusculas")
//     const adcMinusculas = document.querySelector("#minusculas")
//     const adcSimbolos = document.querySelector("#simbolos")

//     let varQuantCaracteres = quantCaracteres.value;
//     let varNumeros = adcNumeros.checked;
//     let varMaiusculas = adcMaiusculas.checked;
//     let varMinusculas = adcMinusculas.checked;
//     let varSimbolos = adcSimbolos.checked;

//     return varQuantCaracteres, varNumeros, varMaiusculas, varMinusculas, varSimbolos

// }



const formulario = document.querySelector("#container-formulario")
let localSenha = document.querySelector("#senha-gerada")


formulario.addEventListener("submit", (e) => {
    e.preventDefault()


    const quantCaracteres = document.querySelector("#quantidade-caracteres")
    const adcNumeros = document.querySelector("#numeros")
    const adcMaiusculas = document.querySelector("#maiusculas")
    const adcMinusculas = document.querySelector("#minusculas")
    const adcSimbolos = document.querySelector("#simbolos")

    if(adcNumeros.checked===false && adcMaiusculas.checked===false && adcMinusculas.checked===false && adcSimbolos.checked===false){
        localSenha.textContent = "SELECIONE ALGUM CAMPO"
        localSenha.style.color = "red"
    }else{
        localSenha.textContent = geradorSenha(quantCaracteres.value, adcNumeros.checked, adcMaiusculas.checked, adcMinusculas.checked, adcSimbolos.checked)
        localSenha.style.color = "black"
    }
    
})


